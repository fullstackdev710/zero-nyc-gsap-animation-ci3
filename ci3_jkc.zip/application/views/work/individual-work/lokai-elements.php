<main id="main" data-router-wrapper="">

   <div class="view-work-type" data-router-view="work-type" data-transition-in="default">
      <section>
         <div class="hero" data-out="fade">
            <img class="bg miq" alt="" src="<?php echo base_url(); ?>/assets/img/Lokai.jpg" style="opacity: 1;">
         </div>

         <div class="work-intro c-120" data-out="fade" data-entrance="basic-fade" data-offset=".65" data-offset-mobile=".85" style="opacity: 1;">
            <h1 class="eyebrow">Project Intro</h1>
            <div class="header">
               <p>Lokai & Elements</p>
            </div>
            <div class="subcopy">
               <p>Custom Build Shopify Solution</p>
               <p><strong>Category:</strong> Consumer, E Commerce, Web</p>
               <p><strong>Client:</strong> Lokai & Elements</p>
               <p><strong>Location:</strong> USA</p>
            </div>
         </div>

         <div class="full-bleed c-60 media-within">
            <div class="image-wrapper" style="--dar: 62.5%; opacity: 0; transform: translate(0px, 20px);" data-out="fade" data-entrance="basic-fade" data-offset=".86" data-offset-mobile=".85">
               <img class="bg preload" data-preload-desktop="<?php echo base_url(); ?>/assets/img/lokai/Lokai-1.png" data-preload-mobile="<?php echo base_url(); ?>/assets/img/lokai/Lokai-1.png" alt="">
            </div>
         </div>

         <div class="full-bleed c-60 media-within">
            <div class="image-wrapper" style="--dar: 52.7778%; opacity: 0; transform: translate(0px, 20px);" data-out="fade" data-entrance="basic-fade" data-offset=".86" data-offset-mobile=".85">
               <img class="bg preload" data-preload-desktop="<?php echo base_url(); ?>/assets/img/lokai/Lokai-2.png" data-preload-mobile="<?php echo base_url(); ?>/assets/img/lokai/Lokai-2.png" alt="">
            </div>
         </div>

         <div class="full-bleed c-60 media-within">
            <div class="image-wrapper" style="--dar: 87.2222%; opacity: 0; transform: translate(0px, 20px);" data-out="fade" data-entrance="basic-fade" data-offset=".86" data-offset-mobile=".85">
               <img class="bg preload" data-preload-desktop="<?php echo base_url(); ?>/assets/img/lokai/Lokai-3.png" data-preload-mobile="<?php echo base_url(); ?>/assets/img/lokai/Lokai-3.png" alt="">
            </div>
         </div>

         <div class="full-bleed c-60 media-within">
            <div class="image-wrapper" style="--dar: 87.2222%; opacity: 0; transform: translate(0px, 20px);" data-out="fade" data-entrance="basic-fade" data-offset=".86" data-offset-mobile=".85">
               <img class="bg preload" data-preload-desktop="<?php echo base_url(); ?>/assets/img/lokai/Lokai-4.jpg" data-preload-mobile="<?php echo base_url(); ?>/assets/img/lokai/Lokai-4.jpg" alt="">
            </div>
         </div>


         <div class="full-text">
            <div class="c-120">
               <div class="inner" data-out="fade" data-entrance="basic-fade" data-offset=".65" data-offset-mobile=".85" style="opacity: 0; transform: translate(0px, 20px);">
                  <h3>Project Description</h3>
                  <p>Two brands in different verticals owned by the same parent. Dedicated support on both the wholesale and retail stores of both companies. Integration with Shiphero, Salesforce, custom script for membership handling, group bundles, and various requirements that neither Shopify nor 3rd party apps could handle. UI / UX modifications, customer support, and day to day enhancement requests.</p>
               </div>
            </div>
         </div>

         <h2 class="closing-link" data-out="fade"><a class="underline" target="_blank" href="https://lokai.com/">Lokai & Elements <span class="arrow-wrapper"><span class="link-out">➚</span><span class="link-out">➚</span></span></a></h2>
         <h2 class="closing-link" data-out="fade"><a class="underline" target="_blank" href="https://www.instagram.com/livelokai/">Instagram <span class="arrow-wrapper"><span class="link-out">➚</span><span class="link-out">➚</span></span></a></h2>
      </section>