<main id="main" data-router-wrapper="">

   <div class="view-work-type" data-router-view="work-type" data-transition-in="default">
      <section>
         <div class="hero" data-out="fade">
            <img class="bg miq" alt="" src="<?php echo base_url(); ?>/assets/img/combo-2.jpg" style="opacity: 1;">
         </div>

         <div class="work-intro c-120" data-out="fade" data-entrance="basic-fade" data-offset=".65" data-offset-mobile=".85" style="opacity: 1;">
            <h1 class="eyebrow">Project Intro</h1>
            <div class="header">
               <p>Combo Boxing</p>
            </div>
            <div class="subcopy">
               <p>Custom Build Shopify Solution</p>
               <p><strong>Category:</strong> Consumer, E Commerce, Web</p>
               <p><strong>Client:</strong> Combo Boxing</p>
               <p><strong>Location:</strong> USA</p>
            </div>
         </div>

         <div class="full-bleed c-60 media-within">
            <div class="image-wrapper" style="--dar: 62.5%; opacity: 0; transform: translate(0px, 20px);" data-out="fade" data-entrance="basic-fade" data-offset=".86" data-offset-mobile=".85">
               <img class="bg preload" data-preload-desktop="<?php echo base_url(); ?>/assets/img/combo-boxing/combo-2.jpg" data-preload-mobile="<?php echo base_url(); ?>/assets/img/combo-boxing/combo-2.jpg" alt="">
            </div>
         </div>

         <div class="full-text">
            <div class="c-120">
               <div class="inner" data-out="fade" data-entrance="basic-fade" data-offset=".65" data-offset-mobile=".85" style="opacity: 0; transform: translate(0px, 20px);">
                  <h3>Project Description</h3>
                  <p> In our world, training is one of the constants that we refuse to compromise on, so for a long time we knew there was something we wanted to create that personifies, not only how we see fitness, but a more profound philosophy: that you aren’t entitled to strength, you earn it.</p>
               </div>
            </div>
         </div>

         <h2 class="closing-link" data-out="fade"><a class="underline" target="_blank" href="https://comboboxing.com/">Combo Boxing <span class="arrow-wrapper"><span class="link-out">➚</span><span class="link-out">➚</span></span></a></h2>
         <h2 class="closing-link" data-out="fade"><a class="underline" target="_blank" href="https://www.instagram.com/comboboxing/">Instagram <span class="arrow-wrapper"><span class="link-out">➚</span><span class="link-out">➚</span></span></a></h2>
      </section>